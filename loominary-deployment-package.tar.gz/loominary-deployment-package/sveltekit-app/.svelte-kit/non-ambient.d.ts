
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/admin" | "/admin/analytics" | "/admin/content" | "/admin/dashboard" | "/admin/security" | "/admin/settings" | "/admin/users" | "/api" | "/auth" | "/auth/login" | "/auth/register" | "/dashboard" | "/legacy" | "/onboarding" | "/onboarding/welcome" | "/pricing" | "/vault";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/admin": Record<string, never>;
			"/admin/analytics": Record<string, never>;
			"/admin/content": Record<string, never>;
			"/admin/dashboard": Record<string, never>;
			"/admin/security": Record<string, never>;
			"/admin/settings": Record<string, never>;
			"/admin/users": Record<string, never>;
			"/api": Record<string, never>;
			"/auth": Record<string, never>;
			"/auth/login": Record<string, never>;
			"/auth/register": Record<string, never>;
			"/dashboard": Record<string, never>;
			"/legacy": Record<string, never>;
			"/onboarding": Record<string, never>;
			"/onboarding/welcome": Record<string, never>;
			"/pricing": Record<string, never>;
			"/vault": Record<string, never>
		};
		Pathname(): "/" | "/admin" | "/admin/" | "/admin/analytics" | "/admin/analytics/" | "/admin/content" | "/admin/content/" | "/admin/dashboard" | "/admin/dashboard/" | "/admin/security" | "/admin/security/" | "/admin/settings" | "/admin/settings/" | "/admin/users" | "/admin/users/" | "/api" | "/api/" | "/auth" | "/auth/" | "/auth/login" | "/auth/login/" | "/auth/register" | "/auth/register/" | "/dashboard" | "/dashboard/" | "/legacy" | "/legacy/" | "/onboarding" | "/onboarding/" | "/onboarding/welcome" | "/onboarding/welcome/" | "/pricing" | "/pricing/" | "/vault" | "/vault/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/favicon.svg" | "/logo.svg" | string & {};
	}
}