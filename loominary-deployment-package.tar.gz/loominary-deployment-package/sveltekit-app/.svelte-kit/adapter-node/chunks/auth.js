import { w as writable } from "./index.js";
import { a as api } from "./api.js";
const initialState = {
  user: null,
  isAuthenticated: false,
  loading: false,
  error: null,
  token: null
};
function createAuthStore() {
  const { subscribe, set, update } = writable(initialState);
  return {
    subscribe,
    async init() {
      return;
    },
    async register(userData) {
      update((state) => ({ ...state, loading: true, error: null }));
      try {
        const response = await api.register(userData);
        update((state) => ({
          ...state,
          user: response.user,
          isAuthenticated: true,
          loading: false,
          token: response.token
        }));
        return response;
      } catch (error) {
        const errorMessage = error.response?.data?.error || "Registration failed";
        update((state) => ({
          ...state,
          loading: false,
          error: errorMessage
        }));
        throw error;
      }
    },
    async login(credentials) {
      update((state) => ({ ...state, loading: true, error: null }));
      try {
        const response = await api.login(credentials);
        update((state) => ({
          ...state,
          user: response.user,
          isAuthenticated: true,
          loading: false,
          token: response.token
        }));
        return response;
      } catch (error) {
        const errorMessage = error.response?.data?.error || "Login failed";
        update((state) => ({
          ...state,
          loading: false,
          error: errorMessage
        }));
        throw error;
      }
    },
    async logout() {
      update((state) => ({ ...state, loading: true }));
      try {
        await api.logout();
      } catch (error) {
        console.error("Logout error:", error);
      } finally {
        set(initialState);
      }
    },
    async updateProfile(profileData) {
      update((state) => ({ ...state, loading: true, error: null }));
      try {
        const updatedUser = await api.updateProfile(profileData);
        update((state) => ({
          ...state,
          user: updatedUser,
          loading: false
        }));
        return updatedUser;
      } catch (error) {
        const errorMessage = error.response?.data?.error || "Profile update failed";
        update((state) => ({
          ...state,
          loading: false,
          error: errorMessage
        }));
        throw error;
      }
    },
    async updatePrivacySettings(settings) {
      update((state) => ({ ...state, loading: true, error: null }));
      try {
        await api.updatePrivacySettings(settings);
        update((state) => ({
          ...state,
          user: state.user ? {
            ...state.user,
            privacy: { ...state.user.privacy, ...settings }
          } : null,
          loading: false
        }));
      } catch (error) {
        const errorMessage = error.response?.data?.error || "Privacy settings update failed";
        update((state) => ({
          ...state,
          loading: false,
          error: errorMessage
        }));
        throw error;
      }
    },
    async updateNotificationSettings(settings) {
      update((state) => ({ ...state, loading: true, error: null }));
      try {
        await api.updateNotificationSettings(settings);
        update((state) => ({
          ...state,
          user: state.user ? {
            ...state.user,
            notifications: { ...state.user.notifications, ...settings }
          } : null,
          loading: false
        }));
      } catch (error) {
        const errorMessage = error.response?.data?.error || "Notification settings update failed";
        update((state) => ({
          ...state,
          loading: false,
          error: errorMessage
        }));
        throw error;
      }
    },
    async forgotPassword(email) {
      update((state) => ({ ...state, loading: true, error: null }));
      try {
        await api.forgotPassword(email);
        update((state) => ({ ...state, loading: false }));
      } catch (error) {
        const errorMessage = error.response?.data?.error || "Password reset request failed";
        update((state) => ({
          ...state,
          loading: false,
          error: errorMessage
        }));
        throw error;
      }
    },
    async resetPassword(token, password) {
      update((state) => ({ ...state, loading: true, error: null }));
      try {
        await api.resetPassword(token, password);
        update((state) => ({ ...state, loading: false }));
      } catch (error) {
        const errorMessage = error.response?.data?.error || "Password reset failed";
        update((state) => ({
          ...state,
          loading: false,
          error: errorMessage
        }));
        throw error;
      }
    },
    async refreshToken() {
      try {
        const response = await api.refreshToken();
        update((state) => ({
          ...state,
          token: response.token
        }));
        return response;
      } catch (error) {
        console.error("Token refresh failed:", error);
        this.logout();
        throw error;
      }
    },
    clearError() {
      update((state) => ({ ...state, error: null }));
    },
    // Utility methods
    hasRole(role) {
      return new Promise((resolve) => {
        const unsubscribe = subscribe((state) => {
          resolve(state.user?.role === role || false);
          unsubscribe();
        });
      });
    },
    hasPermission(permission) {
      return new Promise((resolve) => {
        const unsubscribe = subscribe((state) => {
          if (!state.user) {
            resolve(false);
            unsubscribe();
            return;
          }
          const permissions = {
            user: ["read_own_memories", "create_memories", "update_own_profile"],
            moderator: ["moderate_content", "view_reports", "ban_users"],
            admin: ["manage_users", "manage_system", "view_analytics", "manage_subscriptions"]
          };
          const userPermissions = permissions[state.user.role] || [];
          resolve(userPermissions.includes(permission));
          unsubscribe();
        });
      });
    },
    isSubscriptionActive() {
      return new Promise((resolve) => {
        const unsubscribe = subscribe((state) => {
          resolve(state.user?.subscription !== void 0 && state.user.subscription !== "basic");
          unsubscribe();
        });
      });
    }
  };
}
const authStore = createAuthStore();
export {
  authStore as a
};
