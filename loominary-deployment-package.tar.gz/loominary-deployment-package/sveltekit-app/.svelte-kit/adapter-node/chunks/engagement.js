import { d as derived, w as writable } from "./index.js";
const engagementStore = writable(null);
const dailyPromptsStore = writable([]);
const leaderboardStore = writable([]);
const notificationsStore = writable([]);
const userLevel = derived(engagementStore, ($engagement) => {
  if (!$engagement) return 1;
  return Math.floor($engagement.xp / 1e3) + 1;
});
const nextLevelXP = derived(engagementStore, ($engagement) => {
  if (!$engagement) return 1e3;
  const currentLevel = Math.floor($engagement.xp / 1e3) + 1;
  return currentLevel * 1e3;
});
const levelProgress = derived([engagementStore, nextLevelXP], ([$engagement, $nextLevelXP]) => {
  if (!$engagement) return 0;
  const currentLevelXP = ($engagement.level - 1) * 1e3;
  return ($engagement.xp - currentLevelXP) / 1e3 * 100;
});
const engagementActions = {
  // Initialize user engagement
  async initialize(userId) {
    try {
      const response = await fetch(`/api/engagement/${userId}`);
      if (response.ok) {
        const data = await response.json();
        engagementStore.set(data);
      }
    } catch (error) {
      console.error("Failed to initialize engagement:", error);
    }
  },
  // Track user action and award XP
  async trackAction(action, metadata) {
    try {
      const response = await fetch("/api/engagement/track", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, metadata })
      });
      if (response.ok) {
        const result = await response.json();
        engagementStore.update((current) => {
          if (!current) return current;
          return {
            ...current,
            xp: result.newXP,
            level: result.newLevel,
            achievements: [...current.achievements, ...result.newAchievements]
          };
        });
        if (result.newAchievements.length > 0) {
          this.showAchievements(result.newAchievements);
        }
        return result;
      }
    } catch (error) {
      console.error("Failed to track action:", error);
    }
  },
  // Show achievement notifications
  showAchievements(achievements) {
    achievements.forEach((achievement) => {
      notificationsStore.update((notifications) => [
        ...notifications,
        {
          id: `achievement_${achievement.id}`,
          type: "achievement",
          title: "Achievement Unlocked!",
          message: achievement.title,
          icon: achievement.icon,
          timestamp: /* @__PURE__ */ new Date(),
          autoHide: false
        }
      ]);
    });
  },
  // Load daily content prompts
  async loadDailyPrompts() {
    try {
      const response = await fetch("/api/engagement/prompts/daily");
      if (response.ok) {
        const prompts = await response.json();
        dailyPromptsStore.set(prompts);
      }
    } catch (error) {
      console.error("Failed to load daily prompts:", error);
    }
  },
  // Complete daily goal
  async completeDailyGoal(goalId) {
    try {
      const response = await fetch(`/api/engagement/goals/${goalId}/complete`, {
        method: "POST"
      });
      if (response.ok) {
        const result = await response.json();
        engagementStore.update((current) => {
          if (!current) return current;
          return {
            ...current,
            xp: current.xp + result.xpReward,
            dailyGoals: current.dailyGoals.map(
              (goal) => goal.id === goalId ? { ...goal, completed: true } : goal
            )
          };
        });
        notificationsStore.update((notifications) => [
          ...notifications,
          {
            id: `goal_${goalId}`,
            type: "success",
            title: "Daily Goal Complete!",
            message: `+${result.xpReward} XP earned`,
            icon: "🎯",
            timestamp: /* @__PURE__ */ new Date(),
            autoHide: true
          }
        ]);
      }
    } catch (error) {
      console.error("Failed to complete daily goal:", error);
    }
  },
  // Update streak
  async updateStreak() {
    try {
      const response = await fetch("/api/engagement/streak", {
        method: "POST"
      });
      if (response.ok) {
        const result = await response.json();
        engagementStore.update((current) => {
          if (!current) return current;
          return {
            ...current,
            streak: result.streak,
            xp: current.xp + result.streakBonus
          };
        });
        if (result.streakBonus > 0) {
          notificationsStore.update((notifications) => [
            ...notifications,
            {
              id: `streak_${Date.now()}`,
              type: "streak",
              title: `${result.streak} Day Streak!`,
              message: `+${result.streakBonus} bonus XP`,
              icon: "🔥",
              timestamp: /* @__PURE__ */ new Date(),
              autoHide: true
            }
          ]);
        }
      }
    } catch (error) {
      console.error("Failed to update streak:", error);
    }
  },
  // Load leaderboard
  async loadLeaderboard(type = "weekly") {
    try {
      const response = await fetch(`/api/engagement/leaderboard?type=${type}`);
      if (response.ok) {
        const leaderboard = await response.json();
        leaderboardStore.set(leaderboard);
      }
    } catch (error) {
      console.error("Failed to load leaderboard:", error);
    }
  },
  // Dismiss notification
  dismissNotification(notificationId) {
    notificationsStore.update(
      (notifications) => notifications.filter((n) => n.id !== notificationId)
    );
  }
};
const CONTENT_PROMPTS = [
  {
    id: "childhood_memory",
    title: "Childhood Wonder",
    description: "Preserve a favorite childhood memory in your private vault",
    category: "memory",
    difficulty: "easy",
    xpReward: 75,
    trending: true,
    examples: [
      "Your first day of school",
      "A special birthday celebration",
      "Learning to ride a bike"
    ]
  },
  {
    id: "family_wisdom",
    title: "Life Wisdom",
    description: "Record important life lessons to pass down through generations",
    category: "wisdom",
    difficulty: "medium",
    xpReward: 125,
    trending: true,
    examples: [
      "Career advice you wish you had known",
      "Relationship wisdom from experience",
      "Financial lessons learned"
    ]
  },
  {
    id: "family_recipe",
    title: "Family Recipe",
    description: "Preserve a cherished family recipe with its story",
    category: "tradition",
    difficulty: "easy",
    xpReward: 100,
    trending: false,
    examples: [
      "Grandmother's secret recipe",
      "Holiday cooking traditions",
      "Comfort food memories"
    ]
  },
  {
    id: "voice_message",
    title: "Voice of Love",
    description: "Record an audio message for future family members",
    category: "audio",
    difficulty: "medium",
    xpReward: 150,
    trending: true,
    examples: [
      "Bedtime story you used to tell",
      "Singing a family song",
      "Sharing your hopes for them"
    ]
  },
  {
    id: "time_capsule",
    title: "Time Capsule",
    description: "Create a time capsule to be opened in the future",
    category: "time_capsule",
    difficulty: "hard",
    xpReward: 200,
    trending: true,
    examples: [
      "Letter to your future grandchildren",
      "Predictions about the world in 20 years",
      "Current family photos and stories"
    ]
  },
  {
    id: "family_values",
    title: "Family Values",
    description: "Document the core values that define your family",
    category: "values",
    difficulty: "medium",
    xpReward: 125,
    trending: false,
    examples: [
      "What family means to you",
      "Values you want to pass down",
      "Family mottos or sayings"
    ]
  },
  {
    id: "milestone_moment",
    title: "Milestone Moment",
    description: "Capture an important life milestone in your vault",
    category: "milestone",
    difficulty: "easy",
    xpReward: 100,
    trending: false,
    examples: [
      "Graduation memories",
      "First job experiences",
      "Wedding day reflections"
    ]
  },
  {
    id: "family_history",
    title: "Family Origins",
    description: "Research and document your family's history and origins",
    category: "genealogy",
    difficulty: "hard",
    xpReward: 175,
    trending: false,
    examples: [
      "Immigration stories",
      "Family tree discoveries",
      "Ancestral traditions"
    ]
  },
  {
    id: "personal_growth",
    title: "Growth Journey",
    description: "Reflect on your personal growth and life lessons",
    category: "reflection",
    difficulty: "medium",
    xpReward: 100,
    trending: true,
    examples: [
      "Overcoming challenges",
      "Career journey insights",
      "Personal transformation stories"
    ]
  },
  {
    id: "legacy_letter",
    title: "Legacy Letter",
    description: "Write a heartfelt letter to future generations",
    category: "letter",
    difficulty: "hard",
    xpReward: 200,
    trending: true,
    examples: [
      "Hopes for the future",
      "Family values to preserve",
      "Stories they should know"
    ]
  }
];
export {
  CONTENT_PROMPTS as C,
  engagementActions as a,
  dailyPromptsStore as d,
  engagementStore as e,
  levelProgress as l,
  notificationsStore as n,
  userLevel as u
};
