import { w as writable } from "./index.js";
import { a as api } from "./api.js";
import { c as create_ssr_component, h as compute_rest_props, i as spread, d as each, j as escape_object, k as escape_attribute_value } from "./ssr.js";
const void_element_names = /^(?:area|base|br|col|command|embed|hr|img|input|keygen|link|meta|param|source|track|wbr)$/;
function is_void(name) {
  return void_element_names.test(name) || name.toLowerCase() === "!doctype";
}
const initialState = {
  stats: null,
  loading: false,
  error: null
};
function createAdminStore() {
  const { subscribe, set, update } = writable(initialState);
  return {
    subscribe,
    async getDashboardStats() {
      update((state) => ({ ...state, loading: true, error: null }));
      try {
        const response = await api.get("/admin/dashboard/stats");
        const stats = response.data.stats;
        update((state) => ({ ...state, stats, loading: false }));
        return stats;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Failed to load dashboard stats";
        update((state) => ({ ...state, error: errorMessage, loading: false }));
        throw error;
      }
    },
    async getDashboardData() {
      try {
        const response = await api.get("/admin/dashboard");
        return response.data;
      } catch (error) {
        console.error("Failed to load dashboard data:", error);
        throw error;
      }
    },
    async getUsers(params) {
      try {
        const response = await api.get("/admin/users", { params });
        return response.data;
      } catch (error) {
        console.error("Failed to load users:", error);
        throw error;
      }
    },
    async getUser(userId) {
      try {
        const response = await api.get(`/admin/users/${userId}`);
        return response.data.user;
      } catch (error) {
        console.error("Failed to load user:", error);
        throw error;
      }
    },
    async createUser(userData) {
      try {
        const response = await api.post("/admin/users", userData);
        return response.data.user;
      } catch (error) {
        console.error("Failed to create user:", error);
        throw error;
      }
    },
    async updateUser(userId, userData) {
      try {
        const response = await api.put(`/admin/users/${userId}`, userData);
        return response.data.user;
      } catch (error) {
        console.error("Failed to update user:", error);
        throw error;
      }
    },
    async deleteUser(userId) {
      try {
        await api.delete(`/admin/users/${userId}`);
      } catch (error) {
        console.error("Failed to delete user:", error);
        throw error;
      }
    },
    async banUser(userId) {
      try {
        const response = await api.post(`/admin/users/${userId}/ban`);
        return response.data.user;
      } catch (error) {
        console.error("Failed to ban user:", error);
        throw error;
      }
    },
    async unbanUser(userId) {
      try {
        const response = await api.post(`/admin/users/${userId}/unban`);
        return response.data.user;
      } catch (error) {
        console.error("Failed to unban user:", error);
        throw error;
      }
    },
    async exportUsers(filters) {
      try {
        const response = await api.get("/admin/users/export", {
          params: filters,
          responseType: "blob"
        });
        return response.data;
      } catch (error) {
        console.error("Failed to export users:", error);
        throw error;
      }
    },
    async getContent(params) {
      try {
        const response = await api.get("/admin/content", { params });
        return response.data;
      } catch (error) {
        console.error("Failed to load content:", error);
        throw error;
      }
    },
    async moderateContent(contentId, action, reason) {
      try {
        const response = await api.post(`/admin/content/${contentId}/moderate`, {
          action,
          reason
        });
        return response.data;
      } catch (error) {
        console.error("Failed to moderate content:", error);
        throw error;
      }
    },
    async getAnalytics(params) {
      try {
        const response = await api.get("/admin/analytics", { params });
        return response.data;
      } catch (error) {
        console.error("Failed to load analytics:", error);
        throw error;
      }
    },
    async getSecurityLogs(params) {
      try {
        const response = await api.get("/admin/security/logs", { params });
        return response.data;
      } catch (error) {
        console.error("Failed to load security logs:", error);
        throw error;
      }
    },
    async getSystemHealth() {
      try {
        const response = await api.get("/admin/system/health");
        return response.data;
      } catch (error) {
        console.error("Failed to load system health:", error);
        throw error;
      }
    },
    async getSettings() {
      try {
        const response = await api.get("/admin/settings");
        return response.data.settings;
      } catch (error) {
        console.error("Failed to load settings:", error);
        throw error;
      }
    },
    async updateSettings(settings) {
      try {
        const response = await api.put("/admin/settings", settings);
        return response.data.settings;
      } catch (error) {
        console.error("Failed to update settings:", error);
        throw error;
      }
    },
    async runSecurityScan() {
      try {
        const response = await api.post("/admin/security/scan");
        return response.data;
      } catch (error) {
        console.error("Failed to run security scan:", error);
        throw error;
      }
    },
    async getBackups() {
      try {
        const response = await api.get("/admin/system/backups");
        return response.data.backups;
      } catch (error) {
        console.error("Failed to load backups:", error);
        throw error;
      }
    },
    async createBackup() {
      try {
        const response = await api.post("/admin/system/backups");
        return response.data.backup;
      } catch (error) {
        console.error("Failed to create backup:", error);
        throw error;
      }
    },
    async restoreBackup(backupId) {
      try {
        const response = await api.post(`/admin/system/backups/${backupId}/restore`);
        return response.data;
      } catch (error) {
        console.error("Failed to restore backup:", error);
        throw error;
      }
    },
    async getAuditLogs(params) {
      try {
        const response = await api.get("/admin/audit-logs", { params });
        return response.data;
      } catch (error) {
        console.error("Failed to load audit logs:", error);
        throw error;
      }
    },
    async sendNotification(notification) {
      try {
        const response = await api.post("/admin/notifications/send", notification);
        return response.data;
      } catch (error) {
        console.error("Failed to send notification:", error);
        throw error;
      }
    },
    async getSubscriptionAnalytics() {
      try {
        const response = await api.get("/admin/subscriptions/analytics");
        return response.data;
      } catch (error) {
        console.error("Failed to load subscription analytics:", error);
        throw error;
      }
    },
    async getRevenueAnalytics(params) {
      try {
        const response = await api.get("/admin/revenue/analytics", { params });
        return response.data;
      } catch (error) {
        console.error("Failed to load revenue analytics:", error);
        throw error;
      }
    },
    async getFeatureUsage() {
      try {
        const response = await api.get("/admin/features/usage");
        return response.data;
      } catch (error) {
        console.error("Failed to load feature usage:", error);
        throw error;
      }
    },
    async updateFeatureFlags(flags) {
      try {
        const response = await api.put("/admin/features/flags", flags);
        return response.data;
      } catch (error) {
        console.error("Failed to update feature flags:", error);
        throw error;
      }
    },
    async getPerformanceMetrics() {
      try {
        const response = await api.get("/admin/performance/metrics");
        return response.data;
      } catch (error) {
        console.error("Failed to load performance metrics:", error);
        throw error;
      }
    },
    async getErrorLogs(params) {
      try {
        const response = await api.get("/admin/logs/errors", { params });
        return response.data;
      } catch (error) {
        console.error("Failed to load error logs:", error);
        throw error;
      }
    },
    reset() {
      set(initialState);
    }
  };
}
createAdminStore();
/**
 * @license lucide-svelte v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  "stroke-width": 2,
  "stroke-linecap": "round",
  "stroke-linejoin": "round"
};
const Icon = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["name", "color", "size", "strokeWidth", "absoluteStrokeWidth", "iconNode"]);
  let { name } = $$props;
  let { color = "currentColor" } = $$props;
  let { size = 24 } = $$props;
  let { strokeWidth = 2 } = $$props;
  let { absoluteStrokeWidth = false } = $$props;
  let { iconNode } = $$props;
  if ($$props.name === void 0 && $$bindings.name && name !== void 0) $$bindings.name(name);
  if ($$props.color === void 0 && $$bindings.color && color !== void 0) $$bindings.color(color);
  if ($$props.size === void 0 && $$bindings.size && size !== void 0) $$bindings.size(size);
  if ($$props.strokeWidth === void 0 && $$bindings.strokeWidth && strokeWidth !== void 0) $$bindings.strokeWidth(strokeWidth);
  if ($$props.absoluteStrokeWidth === void 0 && $$bindings.absoluteStrokeWidth && absoluteStrokeWidth !== void 0) $$bindings.absoluteStrokeWidth(absoluteStrokeWidth);
  if ($$props.iconNode === void 0 && $$bindings.iconNode && iconNode !== void 0) $$bindings.iconNode(iconNode);
  return `<svg${spread(
    [
      escape_object(defaultAttributes),
      escape_object($$restProps),
      { width: escape_attribute_value(size) },
      { height: escape_attribute_value(size) },
      { stroke: escape_attribute_value(color) },
      {
        "stroke-width": escape_attribute_value(absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth)
      },
      {
        class: escape_attribute_value(`lucide-icon lucide lucide-${name} ${$$props.class ?? ""}`)
      }
    ],
    {}
  )}>${each(iconNode, ([tag, attrs]) => {
    return `${((tag$1) => {
      return tag$1 ? `<${tag}${spread([escape_object(attrs)], {})}>${is_void(tag$1) ? "" : ``}${is_void(tag$1) ? "" : `</${tag$1}>`}` : "";
    })(tag)}`;
  })}${slots.default ? slots.default({}) : ``}</svg>`;
});
export {
  Icon as I
};
