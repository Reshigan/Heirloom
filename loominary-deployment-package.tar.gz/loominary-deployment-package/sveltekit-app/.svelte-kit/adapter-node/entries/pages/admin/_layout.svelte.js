import { c as create_ssr_component, v as validate_component, a as subscribe, b as add_attribute, d as each, e as escape, m as missing_component } from "../../../chunks/ssr.js";
import "@sveltejs/kit/internal";
import "../../../chunks/exports.js";
import "../../../chunks/utils.js";
import "@sveltejs/kit/internal/server";
import "../../../chunks/state.svelte.js";
import { p as page } from "../../../chunks/stores.js";
import { a as authStore } from "../../../chunks/auth.js";
import { I as Icon } from "../../../chunks/Icon.js";
const Bar_chart_3 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    ["path", { "d": "M3 3v18h18" }],
    ["path", { "d": "M18 17V9" }],
    ["path", { "d": "M13 17V5" }],
    ["path", { "d": "M8 17v-3" }]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "bar-chart-3" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const Bell = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    [
      "path",
      {
        "d": "M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"
      }
    ],
    ["path", { "d": "M10.3 21a1.94 1.94 0 0 0 3.4 0" }]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "bell" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const File_text = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    [
      "path",
      {
        "d": "M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"
      }
    ],
    ["polyline", { "points": "14 2 14 8 20 8" }],
    [
      "line",
      {
        "x1": "16",
        "x2": "8",
        "y1": "13",
        "y2": "13"
      }
    ],
    [
      "line",
      {
        "x1": "16",
        "x2": "8",
        "y1": "17",
        "y2": "17"
      }
    ],
    [
      "line",
      {
        "x1": "10",
        "x2": "8",
        "y1": "9",
        "y2": "9"
      }
    ]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "file-text" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const Home = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    [
      "path",
      {
        "d": "m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"
      }
    ],
    ["polyline", { "points": "9 22 9 12 15 12 15 22" }]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "home" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const Menu = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    [
      "line",
      {
        "x1": "4",
        "x2": "20",
        "y1": "12",
        "y2": "12"
      }
    ],
    [
      "line",
      {
        "x1": "4",
        "x2": "20",
        "y1": "6",
        "y2": "6"
      }
    ],
    [
      "line",
      {
        "x1": "4",
        "x2": "20",
        "y1": "18",
        "y2": "18"
      }
    ]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "menu" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const Settings = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    [
      "path",
      {
        "d": "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"
      }
    ],
    ["circle", { "cx": "12", "cy": "12", "r": "3" }]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "settings" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const Shield = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    [
      "path",
      {
        "d": "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"
      }
    ]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "shield" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const Users = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    [
      "path",
      {
        "d": "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"
      }
    ],
    ["circle", { "cx": "9", "cy": "7", "r": "4" }],
    ["path", { "d": "M22 21v-2a4 4 0 0 0-3-3.87" }],
    ["path", { "d": "M16 3.13a4 4 0 0 1 0 7.75" }]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "users" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const css = {
  code: ".admin-layout{font-family:'Inter', sans-serif}",
  map: '{"version":3,"file":"+layout.svelte","sources":["+layout.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount } from \\"svelte\\";\\nimport { goto } from \\"$app/navigation\\";\\nimport { page } from \\"$app/stores\\";\\nimport { authStore } from \\"$lib/stores/auth\\";\\nimport { adminStore } from \\"$lib/stores/admin\\";\\nimport {\\n  Users,\\n  BarChart3,\\n  Settings,\\n  Shield,\\n  FileText,\\n  Home,\\n  Bell,\\n  Search,\\n  Menu,\\n  X\\n} from \\"lucide-svelte\\";\\nlet sidebarOpen = true;\\nlet user = null;\\nlet adminStats = null;\\nonMount(async () => {\\n  const currentUser = $authStore.user;\\n  if (!currentUser || currentUser.role !== \\"admin\\") {\\n    goto(\\"/dashboard\\");\\n    return;\\n  }\\n  user = currentUser;\\n  try {\\n    adminStats = await adminStore.getDashboardStats();\\n  } catch (error) {\\n    console.error(\\"Failed to load admin stats:\\", error);\\n  }\\n});\\nconst navigation = [\\n  { name: \\"Dashboard\\", href: \\"/admin/dashboard\\", icon: Home },\\n  { name: \\"Users\\", href: \\"/admin/users\\", icon: Users },\\n  { name: \\"Content\\", href: \\"/admin/content\\", icon: FileText },\\n  { name: \\"Analytics\\", href: \\"/admin/analytics\\", icon: BarChart3 },\\n  { name: \\"Security\\", href: \\"/admin/security\\", icon: Shield },\\n  { name: \\"Settings\\", href: \\"/admin/settings\\", icon: Settings }\\n];\\nfunction toggleSidebar() {\\n  sidebarOpen = !sidebarOpen;\\n}\\nfunction isCurrentPage(href) {\\n  return $page.url.pathname === href || $page.url.pathname.startsWith(href + \\"/\\");\\n}\\n<\/script>\\n\\n<div class=\\"min-h-screen bg-base-200\\">\\n  <!-- Sidebar -->\\n  <div class=\\"drawer lg:drawer-open\\">\\n    <input id=\\"admin-drawer\\" type=\\"checkbox\\" class=\\"drawer-toggle\\" bind:checked={sidebarOpen} />\\n    \\n    <!-- Main content -->\\n    <div class=\\"drawer-content flex flex-col\\">\\n      <!-- Top navigation -->\\n      <div class=\\"navbar bg-base-100 shadow-sm border-b\\">\\n        <div class=\\"flex-none lg:hidden\\">\\n          <label for=\\"admin-drawer\\" class=\\"btn btn-square btn-ghost\\">\\n            <Menu class=\\"w-6 h-6\\" />\\n          </label>\\n        </div>\\n        \\n        <div class=\\"flex-1\\">\\n          <h1 class=\\"text-xl font-bold text-primary\\">Loominary Admin</h1>\\n        </div>\\n        \\n        <div class=\\"flex-none gap-2\\">\\n          <!-- Search -->\\n          <div class=\\"form-control\\">\\n            <input type=\\"text\\" placeholder=\\"Search...\\" class=\\"input input-bordered w-24 md:w-auto\\" />\\n          </div>\\n          \\n          <!-- Notifications -->\\n          <div class=\\"dropdown dropdown-end\\">\\n            <div tabindex=\\"0\\" role=\\"button\\" class=\\"btn btn-ghost btn-circle\\">\\n              <div class=\\"indicator\\">\\n                <Bell class=\\"w-5 h-5\\" />\\n                <span class=\\"badge badge-xs badge-primary indicator-item\\"></span>\\n              </div>\\n            </div>\\n            <div tabindex=\\"0\\" class=\\"mt-3 z-[1] card card-compact dropdown-content w-52 bg-base-100 shadow\\">\\n              <div class=\\"card-body\\">\\n                <span class=\\"font-bold text-lg\\">Notifications</span>\\n                <span class=\\"text-info\\">New user registrations: 12</span>\\n                <span class=\\"text-warning\\">Pending content reviews: 5</span>\\n                <span class=\\"text-error\\">Security alerts: 2</span>\\n              </div>\\n            </div>\\n          </div>\\n          \\n          <!-- User menu -->\\n          <div class=\\"dropdown dropdown-end\\">\\n            <div tabindex=\\"0\\" role=\\"button\\" class=\\"btn btn-ghost btn-circle avatar\\">\\n              <div class=\\"w-10 rounded-full\\">\\n                <img src={user?.avatar || `https://ui-avatars.com/api/?name=${user?.firstName}+${user?.lastName}&background=random`} alt=\\"Admin\\" />\\n              </div>\\n            </div>\\n            <ul tabindex=\\"0\\" class=\\"menu menu-sm dropdown-content mt-3 z-[1] p-2 shadow bg-base-100 rounded-box w-52\\">\\n              <li><a href=\\"/dashboard\\">User Dashboard</a></li>\\n              <li><a href=\\"/admin/settings/profile\\">Profile</a></li>\\n              <li><button on:click={() => authStore.logout()}>Logout</button></li>\\n            </ul>\\n          </div>\\n        </div>\\n      </div>\\n      \\n      <!-- Page content -->\\n      <main class=\\"flex-1 p-6\\">\\n        <slot />\\n      </main>\\n    </div>\\n    \\n    <!-- Sidebar -->\\n    <div class=\\"drawer-side\\">\\n      <label for=\\"admin-drawer\\" aria-label=\\"close sidebar\\" class=\\"drawer-overlay\\"></label>\\n      <aside class=\\"min-h-full w-64 bg-base-100 text-base-content\\">\\n        <!-- Logo -->\\n        <div class=\\"p-4 border-b\\">\\n          <div class=\\"flex items-center gap-2\\">\\n            <div class=\\"w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg\\"></div>\\n            <span class=\\"text-lg font-bold\\">Admin Panel</span>\\n          </div>\\n        </div>\\n        \\n        <!-- Navigation -->\\n        <nav class=\\"p-4\\">\\n          <ul class=\\"menu menu-vertical gap-2\\">\\n            {#each navigation as item}\\n              <li>\\n                <a \\n                  href={item.href}\\n                  class=\\"flex items-center gap-3 p-3 rounded-lg transition-colors\\"\\n                  class:bg-primary={isCurrentPage(item.href)}\\n                  class:text-primary-content={isCurrentPage(item.href)}\\n                >\\n                  <svelte:component this={item.icon} class=\\"w-5 h-5\\" />\\n                  {item.name}\\n                </a>\\n              </li>\\n            {/each}\\n          </ul>\\n        </nav>\\n        \\n        <!-- Quick stats -->\\n        {#if adminStats}\\n          <div class=\\"p-4 border-t mt-auto\\">\\n            <h3 class=\\"font-semibold mb-3\\">Quick Stats</h3>\\n            <div class=\\"space-y-2 text-sm\\">\\n              <div class=\\"flex justify-between\\">\\n                <span>Total Users</span>\\n                <span class=\\"font-bold\\">{adminStats.totalUsers?.toLocaleString()}</span>\\n              </div>\\n              <div class=\\"flex justify-between\\">\\n                <span>Active Today</span>\\n                <span class=\\"font-bold text-success\\">{adminStats.activeToday?.toLocaleString()}</span>\\n              </div>\\n              <div class=\\"flex justify-between\\">\\n                <span>Total Memories</span>\\n                <span class=\\"font-bold\\">{adminStats.totalMemories?.toLocaleString()}</span>\\n              </div>\\n              <div class=\\"flex justify-between\\">\\n                <span>Revenue (MTD)</span>\\n                <span class=\\"font-bold text-primary\\">${adminStats.monthlyRevenue?.toLocaleString()}</span>\\n              </div>\\n            </div>\\n          </div>\\n        {/if}\\n      </aside>\\n    </div>\\n  </div>\\n</div>\\n\\n<style>\\n  :global(.admin-layout) {\\n    font-family: \'Inter\', sans-serif;\\n  }\\n</style>"],"names":[],"mappings":"AA+KU,aAAe,CACrB,WAAW,CAAE,OAAO,CAAC,CAAC,UACxB"}'
};
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $page, $$unsubscribe_page;
  let $$unsubscribe_authStore;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  $$unsubscribe_authStore = subscribe(authStore, (value) => value);
  let sidebarOpen = true;
  let user = null;
  const navigation = [
    {
      name: "Dashboard",
      href: "/admin/dashboard",
      icon: Home
    },
    {
      name: "Users",
      href: "/admin/users",
      icon: Users
    },
    {
      name: "Content",
      href: "/admin/content",
      icon: File_text
    },
    {
      name: "Analytics",
      href: "/admin/analytics",
      icon: Bar_chart_3
    },
    {
      name: "Security",
      href: "/admin/security",
      icon: Shield
    },
    {
      name: "Settings",
      href: "/admin/settings",
      icon: Settings
    }
  ];
  function isCurrentPage(href) {
    return $page.url.pathname === href || $page.url.pathname.startsWith(href + "/");
  }
  $$result.css.add(css);
  $$unsubscribe_page();
  $$unsubscribe_authStore();
  return `<div class="min-h-screen bg-base-200"> <div class="drawer lg:drawer-open"><input id="admin-drawer" type="checkbox" class="drawer-toggle"${add_attribute("checked", sidebarOpen, 1)}>  <div class="drawer-content flex flex-col"> <div class="navbar bg-base-100 shadow-sm border-b"><div class="flex-none lg:hidden"><label for="admin-drawer" class="btn btn-square btn-ghost">${validate_component(Menu, "Menu").$$render($$result, { class: "w-6 h-6" }, {}, {})}</label></div> <div class="flex-1" data-svelte-h="svelte-t06msu"><h1 class="text-xl font-bold text-primary">Loominary Admin</h1></div> <div class="flex-none gap-2"> <div class="form-control" data-svelte-h="svelte-vxz86h"><input type="text" placeholder="Search..." class="input input-bordered w-24 md:w-auto"></div>  <div class="dropdown dropdown-end"><div tabindex="0" role="button" class="btn btn-ghost btn-circle"><div class="indicator">${validate_component(Bell, "Bell").$$render($$result, { class: "w-5 h-5" }, {}, {})} <span class="badge badge-xs badge-primary indicator-item"></span></div></div> <div tabindex="0" class="mt-3 z-[1] card card-compact dropdown-content w-52 bg-base-100 shadow" data-svelte-h="svelte-ofb119"><div class="card-body"><span class="font-bold text-lg">Notifications</span> <span class="text-info">New user registrations: 12</span> <span class="text-warning">Pending content reviews: 5</span> <span class="text-error">Security alerts: 2</span></div></div></div>  <div class="dropdown dropdown-end"><div tabindex="0" role="button" class="btn btn-ghost btn-circle avatar"><div class="w-10 rounded-full"><img${add_attribute("src", `https://ui-avatars.com/api/?name=${user?.firstName}+${user?.lastName}&background=random`, 0)} alt="Admin"></div></div> <ul tabindex="0" class="menu menu-sm dropdown-content mt-3 z-[1] p-2 shadow bg-base-100 rounded-box w-52"><li data-svelte-h="svelte-1776s3p"><a href="/dashboard">User Dashboard</a></li> <li data-svelte-h="svelte-19fvtv8"><a href="/admin/settings/profile">Profile</a></li> <li><button data-svelte-h="svelte-rwcadu">Logout</button></li></ul></div></div></div>  <main class="flex-1 p-6">${slots.default ? slots.default({}) : ``}</main></div>  <div class="drawer-side"><label for="admin-drawer" aria-label="close sidebar" class="drawer-overlay"></label> <aside class="min-h-full w-64 bg-base-100 text-base-content"> <div class="p-4 border-b" data-svelte-h="svelte-1vjmzsy"><div class="flex items-center gap-2"><div class="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg"></div> <span class="text-lg font-bold">Admin Panel</span></div></div>  <nav class="p-4"><ul class="menu menu-vertical gap-2">${each(navigation, (item) => {
    return `<li><a${add_attribute("href", item.href, 0)} class="${[
      "flex items-center gap-3 p-3 rounded-lg transition-colors",
      (isCurrentPage(item.href) ? "bg-primary" : "") + " " + (isCurrentPage(item.href) ? "text-primary-content" : "")
    ].join(" ").trim()}">${validate_component(item.icon || missing_component, "svelte:component").$$render($$result, { class: "w-5 h-5" }, {}, {})} ${escape(item.name)}</a> </li>`;
  })}</ul></nav>  ${``}</aside></div></div> </div>`;
});
export {
  Layout as default
};
