import { c as create_ssr_component, v as validate_component, f as createEventDispatcher, e as escape, d as each, b as add_attribute } from "../../../../chunks/ssr.js";
import { I as Icon } from "../../../../chunks/Icon.js";
const Download = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    [
      "path",
      {
        "d": "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"
      }
    ],
    ["polyline", { "points": "7 10 12 15 17 10" }],
    [
      "line",
      {
        "x1": "12",
        "x2": "12",
        "y1": "15",
        "y2": "3"
      }
    ]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "download" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const Plus = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [["path", { "d": "M5 12h14" }], ["path", { "d": "M12 5v14" }]];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "plus" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const Search = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    ["circle", { "cx": "11", "cy": "11", "r": "8" }],
    ["path", { "d": "m21 21-4.3-4.3" }]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "search" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const css = {
  code: ".bulk-actions.svelte-16ry4dz{display:flex;align-items:center;gap:1rem;padding:1rem;background:rgba(26, 26, 26, 0.9);border:1px solid rgba(212, 175, 55, 0.2);border-radius:8px;margin-bottom:1rem}.selection-info.svelte-16ry4dz{color:#F4E5C2;font-size:0.875rem}.selection-controls.svelte-16ry4dz{display:flex;gap:0.5rem}.control-button.svelte-16ry4dz{background:rgba(212, 175, 55, 0.1);border:1px solid rgba(212, 175, 55, 0.3);color:#D4AF37;padding:0.5rem 1rem;border-radius:6px;font-size:0.875rem;cursor:pointer;transition:all 0.3s ease}.control-button.svelte-16ry4dz:hover{background:rgba(212, 175, 55, 0.2)}.actions.svelte-16ry4dz{display:flex;gap:0.5rem;margin-left:auto}.action-button.svelte-16ry4dz{background:linear-gradient(135deg, #B8941F, #D4AF37);border:none;color:#0A0A0A;padding:0.5rem 1rem;border-radius:6px;font-size:0.875rem;font-weight:500;cursor:pointer;transition:all 0.3s ease}.action-button.svelte-16ry4dz:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(212, 175, 55, 0.3)}.action-button.danger.svelte-16ry4dz{background:linear-gradient(135deg, #DC2626, #EF4444);color:white}.action-button.danger.svelte-16ry4dz:hover{box-shadow:0 4px 12px rgba(220, 38, 38, 0.3)}.hidden.svelte-16ry4dz{display:none}",
  map: `{"version":3,"file":"BulkActions.svelte","sources":["BulkActions.svelte"],"sourcesContent":["<script>\\n  import { createEventDispatcher } from 'svelte';\\n  \\n  export let selectedItems = [];\\n  export let totalItems = 0;\\n  export let actions = [];\\n\\n  const dispatch = createEventDispatcher();\\n\\n  function handleAction(action) {\\n    dispatch('action', {\\n      action: action.id,\\n      items: selectedItems\\n    });\\n  }\\n\\n  function selectAll() {\\n    dispatch('selectAll');\\n  }\\n\\n  function clearSelection() {\\n    dispatch('clearSelection');\\n  }\\n\\n  $: hasSelection = selectedItems.length > 0;\\n  $: allSelected = selectedItems.length === totalItems && totalItems > 0;\\n<\/script>\\n\\n<style>\\n  .bulk-actions {\\n    display: flex;\\n    align-items: center;\\n    gap: 1rem;\\n    padding: 1rem;\\n    background: rgba(26, 26, 26, 0.9);\\n    border: 1px solid rgba(212, 175, 55, 0.2);\\n    border-radius: 8px;\\n    margin-bottom: 1rem;\\n  }\\n\\n  .selection-info {\\n    color: #F4E5C2;\\n    font-size: 0.875rem;\\n  }\\n\\n  .selection-controls {\\n    display: flex;\\n    gap: 0.5rem;\\n  }\\n\\n  .control-button {\\n    background: rgba(212, 175, 55, 0.1);\\n    border: 1px solid rgba(212, 175, 55, 0.3);\\n    color: #D4AF37;\\n    padding: 0.5rem 1rem;\\n    border-radius: 6px;\\n    font-size: 0.875rem;\\n    cursor: pointer;\\n    transition: all 0.3s ease;\\n  }\\n\\n  .control-button:hover {\\n    background: rgba(212, 175, 55, 0.2);\\n  }\\n\\n  .actions {\\n    display: flex;\\n    gap: 0.5rem;\\n    margin-left: auto;\\n  }\\n\\n  .action-button {\\n    background: linear-gradient(135deg, #B8941F, #D4AF37);\\n    border: none;\\n    color: #0A0A0A;\\n    padding: 0.5rem 1rem;\\n    border-radius: 6px;\\n    font-size: 0.875rem;\\n    font-weight: 500;\\n    cursor: pointer;\\n    transition: all 0.3s ease;\\n  }\\n\\n  .action-button:hover {\\n    transform: translateY(-1px);\\n    box-shadow: 0 4px 12px rgba(212, 175, 55, 0.3);\\n  }\\n\\n  .action-button.danger {\\n    background: linear-gradient(135deg, #DC2626, #EF4444);\\n    color: white;\\n  }\\n\\n  .action-button.danger:hover {\\n    box-shadow: 0 4px 12px rgba(220, 38, 38, 0.3);\\n  }\\n\\n  .hidden {\\n    display: none;\\n  }\\n</style>\\n\\n<div class=\\"bulk-actions\\" class:hidden={!hasSelection}>\\n  <div class=\\"selection-info\\">\\n    {selectedItems.length} of {totalItems} items selected\\n  </div>\\n  \\n  <div class=\\"selection-controls\\">\\n    {#if !allSelected}\\n      <button class=\\"control-button\\" on:click={selectAll}>\\n        Select All\\n      </button>\\n    {/if}\\n    \\n    <button class=\\"control-button\\" on:click={clearSelection}>\\n      Clear Selection\\n    </button>\\n  </div>\\n  \\n  <div class=\\"actions\\">\\n    {#each actions as action}\\n      <button \\n        class=\\"action-button\\" \\n        class:danger={action.type === 'danger'}\\n        on:click={() => handleAction(action)}\\n        disabled={!hasSelection}\\n      >\\n        {#if action.icon}\\n          <span class=\\"icon\\">{action.icon}</span>\\n        {/if}\\n        {action.label}\\n      </button>\\n    {/each}\\n  </div>\\n</div>"],"names":[],"mappings":"AA6BE,4BAAc,CACZ,OAAO,CAAE,IAAI,CACb,WAAW,CAAE,MAAM,CACnB,GAAG,CAAE,IAAI,CACT,OAAO,CAAE,IAAI,CACb,UAAU,CAAE,KAAK,EAAE,CAAC,CAAC,EAAE,CAAC,CAAC,EAAE,CAAC,CAAC,GAAG,CAAC,CACjC,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,KAAK,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,EAAE,CAAC,CAAC,GAAG,CAAC,CACzC,aAAa,CAAE,GAAG,CAClB,aAAa,CAAE,IACjB,CAEA,8BAAgB,CACd,KAAK,CAAE,OAAO,CACd,SAAS,CAAE,QACb,CAEA,kCAAoB,CAClB,OAAO,CAAE,IAAI,CACb,GAAG,CAAE,MACP,CAEA,8BAAgB,CACd,UAAU,CAAE,KAAK,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,EAAE,CAAC,CAAC,GAAG,CAAC,CACnC,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,KAAK,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,EAAE,CAAC,CAAC,GAAG,CAAC,CACzC,KAAK,CAAE,OAAO,CACd,OAAO,CAAE,MAAM,CAAC,IAAI,CACpB,aAAa,CAAE,GAAG,CAClB,SAAS,CAAE,QAAQ,CACnB,MAAM,CAAE,OAAO,CACf,UAAU,CAAE,GAAG,CAAC,IAAI,CAAC,IACvB,CAEA,8BAAe,MAAO,CACpB,UAAU,CAAE,KAAK,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,EAAE,CAAC,CAAC,GAAG,CACpC,CAEA,uBAAS,CACP,OAAO,CAAE,IAAI,CACb,GAAG,CAAE,MAAM,CACX,WAAW,CAAE,IACf,CAEA,6BAAe,CACb,UAAU,CAAE,gBAAgB,MAAM,CAAC,CAAC,OAAO,CAAC,CAAC,OAAO,CAAC,CACrD,MAAM,CAAE,IAAI,CACZ,KAAK,CAAE,OAAO,CACd,OAAO,CAAE,MAAM,CAAC,IAAI,CACpB,aAAa,CAAE,GAAG,CAClB,SAAS,CAAE,QAAQ,CACnB,WAAW,CAAE,GAAG,CAChB,MAAM,CAAE,OAAO,CACf,UAAU,CAAE,GAAG,CAAC,IAAI,CAAC,IACvB,CAEA,6BAAc,MAAO,CACnB,SAAS,CAAE,WAAW,IAAI,CAAC,CAC3B,UAAU,CAAE,CAAC,CAAC,GAAG,CAAC,IAAI,CAAC,KAAK,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,EAAE,CAAC,CAAC,GAAG,CAC/C,CAEA,cAAc,sBAAQ,CACpB,UAAU,CAAE,gBAAgB,MAAM,CAAC,CAAC,OAAO,CAAC,CAAC,OAAO,CAAC,CACrD,KAAK,CAAE,KACT,CAEA,cAAc,sBAAO,MAAO,CAC1B,UAAU,CAAE,CAAC,CAAC,GAAG,CAAC,IAAI,CAAC,KAAK,GAAG,CAAC,CAAC,EAAE,CAAC,CAAC,EAAE,CAAC,CAAC,GAAG,CAC9C,CAEA,sBAAQ,CACN,OAAO,CAAE,IACX"}`
};
const BulkActions = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let hasSelection;
  let allSelected;
  let { selectedItems = [] } = $$props;
  let { totalItems = 0 } = $$props;
  let { actions = [] } = $$props;
  createEventDispatcher();
  if ($$props.selectedItems === void 0 && $$bindings.selectedItems && selectedItems !== void 0) $$bindings.selectedItems(selectedItems);
  if ($$props.totalItems === void 0 && $$bindings.totalItems && totalItems !== void 0) $$bindings.totalItems(totalItems);
  if ($$props.actions === void 0 && $$bindings.actions && actions !== void 0) $$bindings.actions(actions);
  $$result.css.add(css);
  hasSelection = selectedItems.length > 0;
  allSelected = selectedItems.length === totalItems && totalItems > 0;
  return `<div class="${["bulk-actions svelte-16ry4dz", !hasSelection ? "hidden" : ""].join(" ").trim()}"><div class="selection-info svelte-16ry4dz">${escape(selectedItems.length)} of ${escape(totalItems)} items selected</div> <div class="selection-controls svelte-16ry4dz">${!allSelected ? `<button class="control-button svelte-16ry4dz" data-svelte-h="svelte-lzrav">Select All</button>` : ``} <button class="control-button svelte-16ry4dz" data-svelte-h="svelte-vpu00h">Clear Selection</button></div> <div class="actions svelte-16ry4dz">${each(actions, (action) => {
    return `<button class="${["action-button svelte-16ry4dz", action.type === "danger" ? "danger" : ""].join(" ").trim()}" ${!hasSelection ? "disabled" : ""}>${action.icon ? `<span class="icon">${escape(action.icon)}</span>` : ``} ${escape(action.label)} </button>`;
  })}</div></div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let users = [];
  let searchQuery = "";
  let selectedUsers = [];
  let totalUsers = 0;
  return `${$$result.head += `<!-- HEAD_svelte-snqxgv_START -->${$$result.title = `<title>User Management - Loominary Admin</title>`, ""}<!-- HEAD_svelte-snqxgv_END -->`, ""} <div class="space-y-6"> <div class="flex justify-between items-center"><div data-svelte-h="svelte-acrgsx"><h1 class="text-3xl font-bold text-base-content">User Management</h1> <p class="text-base-content/70 mt-1">Manage and monitor all platform users</p></div> <div class="flex gap-2"><button class="btn btn-outline">${validate_component(Download, "Download").$$render($$result, { class: "w-4 h-4 mr-2" }, {}, {})}
        Export</button> <button class="btn btn-primary">${validate_component(Plus, "Plus").$$render($$result, { class: "w-4 h-4 mr-2" }, {}, {})}
        Add User</button></div></div>  <div class="card bg-base-100 shadow-sm"><div class="card-body"><div class="flex flex-col lg:flex-row gap-4"> <div class="flex-1"><div class="form-control"><div class="input-group"><input type="text" placeholder="Search users..." class="input input-bordered flex-1"${add_attribute("value", searchQuery, 0)}> <button class="btn btn-square">${validate_component(Search, "Search").$$render($$result, { class: "w-5 h-5" }, {}, {})}</button></div></div></div>  <div class="flex gap-2"><select class="select select-bordered"><option value="all" data-svelte-h="svelte-rskcdc">All Status</option><option value="active" data-svelte-h="svelte-1mh57he">Active</option><option value="inactive" data-svelte-h="svelte-okme9y">Inactive</option><option value="banned" data-svelte-h="svelte-17q6mb2">Banned</option></select> <select class="select select-bordered"><option value="all" data-svelte-h="svelte-lw01iy">All Subscriptions</option><option value="basic" data-svelte-h="svelte-1f9rwq6">Basic</option><option value="premium" data-svelte-h="svelte-yigl7g">Premium</option><option value="family" data-svelte-h="svelte-bo6w2u">Family</option><option value="enterprise" data-svelte-h="svelte-1acjxo6">Enterprise</option></select> <select class="select select-bordered"><option value="all" data-svelte-h="svelte-1yhiy9v">All Roles</option><option value="user" data-svelte-h="svelte-1u8kdru">User</option><option value="moderator" data-svelte-h="svelte-1txb7g">Moderator</option><option value="admin" data-svelte-h="svelte-17op260">Admin</option></select></div></div>  <div class="flex justify-between items-center mt-4"><span class="text-sm text-base-content/70">Showing ${escape(users.length)} of ${escape(totalUsers)} users</span> ${selectedUsers.length > 0 ? `${validate_component(BulkActions, "BulkActions").$$render($$result, { selectedCount: selectedUsers.length }, {}, {})}` : ``}</div></div></div>  <div class="card bg-base-100 shadow-sm"><div class="card-body p-0">${`<div class="flex justify-center items-center h-64" data-svelte-h="svelte-1u3cl2f"><span class="loading loading-spinner loading-lg"></span></div>`}</div></div></div>  ${``}`;
});
export {
  Page as default
};
