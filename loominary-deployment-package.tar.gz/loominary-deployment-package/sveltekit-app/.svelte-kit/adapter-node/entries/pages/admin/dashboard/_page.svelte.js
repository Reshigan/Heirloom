import { c as create_ssr_component, v as validate_component } from "../../../../chunks/ssr.js";
import { I as Icon } from "../../../../chunks/Icon.js";
const Clock = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    ["circle", { "cx": "12", "cy": "12", "r": "10" }],
    ["polyline", { "points": "12 6 12 12 16 14" }]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "clock" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${$$result.head += `<!-- HEAD_svelte-1cmiz1l_START -->${$$result.title = `<title>Admin Dashboard - Loominary</title>`, ""}<!-- HEAD_svelte-1cmiz1l_END -->`, ""} <div class="space-y-6"> <div class="flex justify-between items-center"><div data-svelte-h="svelte-1u700r"><h1 class="text-3xl font-bold text-base-content">Dashboard</h1> <p class="text-base-content/70 mt-1">Welcome back! Here&#39;s what&#39;s happening with your platform.</p></div> <div class="flex gap-2"><button class="btn btn-outline">${validate_component(Clock, "Clock").$$render($$result, { class: "w-4 h-4 mr-2" }, {}, {})}
        Last 24h</button> <button class="btn btn-primary" data-svelte-h="svelte-17c5u52">Export Report</button></div></div> ${`<div class="flex justify-center items-center h-64" data-svelte-h="svelte-g95siv"><span class="loading loading-spinner loading-lg"></span></div>`}</div>`;
});
export {
  Page as default
};
