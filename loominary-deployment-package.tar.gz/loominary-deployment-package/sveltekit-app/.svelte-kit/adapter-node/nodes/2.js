

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/admin/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.CK1P1LdR.js","_app/immutable/chunks/CQUioi9L.js","_app/immutable/chunks/C8HSDaph.js","_app/immutable/chunks/IHki7fMi.js","_app/immutable/chunks/B0DaUPK-.js","_app/immutable/chunks/CLZLjHdP.js","_app/immutable/chunks/YpDyjAOD.js","_app/immutable/chunks/CiOcjzeO.js","_app/immutable/chunks/YBdKmd65.js","_app/immutable/chunks/CnJJdmvZ.js","_app/immutable/chunks/CaU0s07t.js","_app/immutable/chunks/kkjbmiuP.js","_app/immutable/chunks/6kv4xdVF.js","_app/immutable/chunks/BpUyg57M.js"];
export const stylesheets = ["_app/immutable/assets/2.C4anevxW.css"];
export const fonts = [];
