

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.BeTuSHXu.js","_app/immutable/chunks/CQUioi9L.js","_app/immutable/chunks/IHki7fMi.js","_app/immutable/chunks/YpDyjAOD.js","_app/immutable/chunks/B0DaUPK-.js","_app/immutable/chunks/CLZLjHdP.js"];
export const stylesheets = [];
export const fonts = [];
