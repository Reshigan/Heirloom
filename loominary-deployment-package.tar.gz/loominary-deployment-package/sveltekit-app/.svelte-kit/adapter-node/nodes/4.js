

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/admin/dashboard/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.D2i2PwS2.js","_app/immutable/chunks/CQUioi9L.js","_app/immutable/chunks/C8HSDaph.js","_app/immutable/chunks/IHki7fMi.js","_app/immutable/chunks/CnJJdmvZ.js","_app/immutable/chunks/CLZLjHdP.js","_app/immutable/chunks/YBdKmd65.js","_app/immutable/chunks/B0DaUPK-.js","_app/immutable/chunks/CaU0s07t.js","_app/immutable/chunks/kkjbmiuP.js","_app/immutable/chunks/6kv4xdVF.js"];
export const stylesheets = ["_app/immutable/assets/4.CQL-7RfY.css"];
export const fonts = [];
