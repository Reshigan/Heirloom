

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.BJChzv8_.js","_app/immutable/chunks/CQUioi9L.js","_app/immutable/chunks/IHki7fMi.js","_app/immutable/chunks/C8HSDaph.js","_app/immutable/chunks/CLZLjHdP.js","_app/immutable/chunks/Ciict3cn.js","_app/immutable/chunks/CaU0s07t.js","_app/immutable/chunks/BpUyg57M.js","_app/immutable/chunks/kkjbmiuP.js"];
export const stylesheets = ["_app/immutable/assets/3.B7Yon5eF.css"];
export const fonts = [];
